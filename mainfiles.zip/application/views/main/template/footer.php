          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>sambadi &copy; 2018</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a href="https://bootstrapious.com/admin-templates" class="external">Bootstrapious</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo base_url() ?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/popper.min.js"> </script>
    <script src="<?php echo base_url() ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/jquery.cookie.js"> </script>
    <script src="<?php echo base_url() ?>/assets/js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/jquery.validate.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/charts-home.js"></script>
    <!-- Main File-->
    <script src="<?php echo base_url() ?>/assets/js/front.js"></script>
    <script>
      $(document).ready(function() {
        setTimeout(function() {
          $('.loader-wrapper').fadeOut(500);
        }, 1500);
      });
    </script>
  </body>
</html>