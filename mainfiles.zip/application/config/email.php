<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| EMAIL CONFING
| -------------------------------------------------------------------
| Configuration of outgoing mail server.
| */
$config['smtp_host']='smtp.gmail.com';
$config['smtp_port']=465;
$config['smtp_timeout']=30;
$config['smtp_user']='sambadigodd@gmail.com';
$config['smtp_pass']='mirage123';
$config['charset']='utf-8';  
$config['newline']= "\r\n";
$config['mailtype'] = "html";

/* End of file email.php */
/* Location: ./system/application/config/email.php */